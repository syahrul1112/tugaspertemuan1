package CRUD;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        String nama, nim;
        int usia, uts, uas, pilih;
        double nilaiAkhir;
        
        Scanner input = new Scanner(System.in);
        
        System.out.println("----Input data-----");
        System.out.print("Nama\t: ");nama = input.nextLine();
        System.out.print("NIM\t: ");nim = input.nextLine();
        System.out.print("Usia\t: ");usia = input.nextInt();
        System.out.print("UTS\t: ");uts = input.nextInt();
        System.out.print("UAS\t: ");uas = input.nextInt();
        
        Mahasiswa mahasiswa = new Mahasiswa(nama,nim,usia,uts,uas);
        
        do{
            System.out.print("\n----Menu-----\n1. Tampilkan data\n2. Edit data\n3. Exit\nPilih  : ");
            pilih=input.nextInt();
            
            if(pilih==1){
                System.out.println("Nama           : "+ mahasiswa.nama);
                System.out.println("NIM            : "+ mahasiswa.nim);
                System.out.println("Usia           : "+ mahasiswa.usia);
                System.out.println("Nilai Akhir    : "+ mahasiswa.nilaiAkhir());
            }
            else if(pilih==2){
                input = new Scanner(System.in);
                System.out.println("\n\n----Input Data----");
                System.out.print("Nama\t: ");mahasiswa.nama = input.nextLine();
                System.out.print("NIM\t: ");mahasiswa.nim = input.nextLine();
                System.out.print("Usia\t: ");mahasiswa.usia = input.nextInt();
                System.out.print("UTS\t: ");mahasiswa.uts = input.nextInt();
                System.out.print("UAS\t: ");mahasiswa.uas = input.nextInt();
            }
            else if(pilih<1 || pilih > 3){
                System.out.println("\nAngka yang anda masukkan salah!\n");
            }
            
        }while(pilih != 3);
    }
    
}
